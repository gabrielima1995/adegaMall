namespace Application.Config.Modules.Product
{
    /// <summary>
    /// Configura��o de um raio de entrega de frota pr�pria/privada.
    /// </summary>
    public class PrivateFleetParameterConfig
    {
        /// <summary>
        /// Raio de entrega, em quil�metros.
        /// </summary>
        public int Range { get; set; }
    }
}