using Application.Config.Common;
using Domain.Config.Modules.Product;
using System.Collections.Generic;

namespace Application.Config.Modules.Product
{
    /// <summary>
    /// Configura��o de entrega de frota pr�pria/privada.
    /// </summary>
    public class PrivateFleetShippingConfig : StatusConfig
    {
        /// <summary>
        /// Par�metros padr�o de raio de entrega.
        /// </summary>
        public IList<PrivateFleetParameterConfig> DefaultParams { get; set; } = new List<PrivateFleetParameterConfig>
        {
            new PrivateFleetParameterConfig
            {
                Range = 5
            },
            new PrivateFleetParameterConfig
            {
                Range = 10
            },
            new PrivateFleetParameterConfig
            {
                Range = 20
            }
        };

        public bool AllowFreeShipping { get; set; }

        public DeliveryTimeMessageConfig DeliveryTimeMessage { get; set; } = new DeliveryTimeMessageConfig(false, "PRIVATE_FLEET_SHIPPING_DELIVERY_TIME");
    }
}