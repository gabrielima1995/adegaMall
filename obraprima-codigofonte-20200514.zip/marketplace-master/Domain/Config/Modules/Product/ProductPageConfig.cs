using Application.Config.Common;

namespace Application.Config.Modules.Product
{
    /// <summary>
    /// Configura��o da p�gina de produto.
    /// </summary>
    public class ProductPageConfig
    {
        /// <summary>
        /// Campo Quantidade na p�gina do produto.
        /// </summary>
        public StatusConfig Quantity { get; set; } = new StatusConfig();
    }
}