using System;
using Application.Config.Common;

namespace Application.Config.Modules.Product
{
    /// <summary>
    /// Configura��o de busca no m�dulo de produtos.
    /// </summary>
    [Obsolete("Migrado para SearchConfig")]
    public class ProductSearchConfig
    {
        /// <summary>
        /// Filtro busca em texto livre.
        /// </summary>
        public StatusConfig ByQuery { get; set; } = new StatusConfig();

        /// <summary>
        /// Filtro por cidade/estado.
        /// </summary>
        public StatusConfig ByCityAndState { get; set; } = new StatusConfig();

        /// <summary>
        /// Filtro por categoria.
        /// </summary>
        public StatusConfig ByCategories { get; set; } = new StatusConfig();

        /// <summary>
        /// Filtro somente por retirada no local.
        /// </summary>
        public StatusConfig ByOnlyOnsitePickup { get; set; } = new StatusConfig();

        /// <summary>
        /// Filtro somente por entrega f�sica.
        /// </summary>
        public StatusConfig ByOnlyShippingOut { get; set; } = new StatusConfig();

        /// <summary>
        /// Se login � obrigat�rio para visualizar resultados da busca.
        /// </summary>
        public bool RequireLogin { get; set; } = false;

        /// <summary>
        /// N�mero de resultados por p�gina.
        /// </summary>
        public int ResultsByPage { get; set; } = 21;
    }
}