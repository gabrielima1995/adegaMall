using Application.Config.Common;
using Application.Config.Modules.Product;
using Domain.Config.Modules.Product;
using Domain.Entities.StoreModule;
using FluentValidation;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace Application.Config.Modules
{
    /// <summary>
    /// Configura��o do m�dulo de produtos.
    /// </summary>
    public class ProductConfig : StatusConfig
    {
        public BusinessModelConfig BusinessModel { get; set; } = new BusinessModelConfig();

        public int ProductsLimit { get; set; }

        public bool EnableInstallmentsPerProduct { get; set; } = false;

        public bool CanPauseProducts { get; set; } = false;

        public bool ShowRelatedProducts { get; set; } = false;

        /// <summary>
        /// Oculta a navega��o de loja e produtos do Minha Conta do Vendedor.
        /// </summary>
        public bool HideStoreMenusFromSeller { get; set; } = false;

        public RegisterConfig Image { get; set; } = new RegisterConfig();

        public RegisterConfig Specifications { get; set; } = new RegisterConfig();

        public RegisterConfig CustomId { get; set; } = new RegisterConfig();

        public RegisterConfig Category { get; set; } = new RegisterConfig();

        public RegisterConfig Price { get; set; } = new RegisterConfig();

        public StatusConfig DiscountPrice { get; set; } = new StatusConfig(true);

        public RegisterConfig Length { get; set; } = new RegisterConfig();

        public RegisterConfig Width { get; set; } = new RegisterConfig();

        public RegisterConfig Height { get; set; } = new RegisterConfig();

        public RegisterConfig Weight { get; set; } = new RegisterConfig();

        [JsonIgnore]
        public bool AnyDimensionsEnabled => Length.Enabled || Width.Enabled || Height.Enabled || Weight.Enabled;

        /// <summary>
        /// Configura��o da p�gina de detalhes do produto.
        /// </summary>
        public ProductPageConfig Page { get; set; } = new ProductPageConfig();

        /// <summary>
        /// Configura��o de variantes de produto.
        /// </summary>
        public VariantsConfig Variants { get; set; } = new VariantsConfig();

        /// <summary>
        /// Configura��o de busca no m�dulo de produtos.
        /// </summary>
        public ProductSearchConfig Search { get; set; } = new ProductSearchConfig();

        /// <summary>
        /// Configura��o de avalia��o de pedido
        /// </summary>
        public OrderReviewConfig OrderReview { get; set; } = new OrderReviewConfig();

        /// <summary>
        /// Configura��es gerais de pedidos.
        /// </summary>
        public OrderConfig Order { get; set; } = new OrderConfig();

        /// <summary>
        /// Configura��es gerais de Estoque.
        /// </summary>
        public StockConfig Stock { get; set; } = new StockConfig();

        #region Shipping

        /// <summary>
        /// Configura��o de modalidade de opera��o de frete suportada pela plataforma.
        /// </summary>
        public ShippingMode ShippingMode { get; set; }

        /// <summary>
        /// Configura��o de entrega de frota pr�pria/privada.
        /// </summary>
        public PrivateFleetShippingConfig PrivateFleetShipping { get; set; } = new PrivateFleetShippingConfig();

        /// <summary>
        /// Configura��o de retirada no local.
        /// </summary>
        public OnSitePickupShippingConfig OnSitePickupShipping { get; set; } = new OnSitePickupShippingConfig();

        /// <summary>
        /// Configura��o de entrega de produto digital/download (sem entrega f�sica).
        /// </summary>
        public NoShippingConfig NoShipping { get; set; } = new NoShippingConfig();

        /// <summary>
        /// Configura��o de entrega de produto sem entrega (ex. servi�os, itens entregues por fora da plataforma).
        /// </summary>
        public ActualNoShippingConfig ActualNoShipping { get; set; } = new ActualNoShippingConfig();

        /// <summary>
        /// Configura��o de entrega Correios Sedex.
        /// </summary>
        public PostalExpressShippingConfig SedexShipping { get; set; } = new PostalExpressShippingConfig();

        /// <summary>
        /// Configura��o de entrega Correios PAC.
        /// </summary>
        public PostalRegularShippingConfig PACShipping { get; set; } = new PostalRegularShippingConfig();

        public int CorreiosTimeoutSeconds { get; set; } = 6;

        /// <summary>
        /// Define os dados de contrato com os Correios, para uso no WebService de c�lculo de pre�o e prazo.
        /// </summary>
        public CorreiosContractConfig CorreiosContract { get; set; } = new CorreiosContractConfig();

        /// <summary>
        /// Indica se pelo menos um m�todo de entrega est� habilitado no m�dulo.
        /// </summary>
        [JsonIgnore]
        public bool SomeShippingMethodEnabled => GetShippingMethodsEnabled().Count > 0;

        [JsonIgnore]
        public bool HasPhysicalShipping => GetShippingMethodsEnabled().Intersect(new[] { ShippingMethod.PostalExpress, ShippingMethod.PostalRegular, ShippingMethod.PrivateFleet }).Any();

        /// <summary>
        /// Indica se somente um m�todo de entrega est� habilitado no m�dulo.
        /// </summary>
        [JsonIgnore]
        public bool OnlyOneShippingMethodEnabled => GetShippingMethodsEnabled().Count == 1;

        /// <summary>
        /// Prioriza Sedex no checkout se habilitado
        /// </summary>
        public bool PrioritizeExpressShipping { get; set; } = false;

        /// <summary>
        /// Obtem os m�todos de entrega habilitados no m�dulo.
        /// </summary>
        public IList<ShippingMethod> GetShippingMethodsEnabled()
        {
            var list = new List<ShippingMethod>();

            if (ShippingMode == ShippingMode.PerProduct)
            {
                if (PrivateFleetShipping.Enabled)
                    list.Add(ShippingMethod.PrivateFleet);

                if (OnSitePickupShipping.Enabled)
                    list.Add(ShippingMethod.OnSitePickup);

                if (NoShipping.Enabled)
                    list.Add(ShippingMethod.NoShipping);

                if (ActualNoShipping.Enabled)
                    list.Add(ShippingMethod.ActualNoShipping);

                if (SedexShipping.Enabled)
                    list.Add(ShippingMethod.PostalExpress);

                if (PACShipping.Enabled)
                    list.Add(ShippingMethod.PostalRegular);
            }
            else if (ShippingMode == ShippingMode.PerStore)
            {
                if (PrivateFleetShipping.Enabled)
                    list.Add(ShippingMethod.PrivateFleet);

                if (OnSitePickupShipping.Enabled)
                    list.Add(ShippingMethod.OnSitePickup);

                if (SedexShipping.Enabled)
                    list.Add(ShippingMethod.PostalExpress);

                if (PACShipping.Enabled)
                    list.Add(ShippingMethod.PostalRegular);
            }

            return list;
        }

        #endregion Shipping

        /// <summary>
        /// Configura��es de lista de desejos (produtos favoritados).
        /// </summary>
        public StatusConfig Wishlist { get; set; } = new StatusConfig(false);

        /// <summary>
        /// Configura��es para modelos de produtos.
        /// </summary>
        public ProductTemplatesConfig Templates { get; set; } = new ProductTemplatesConfig();

        public ProductConfig() : base(enabled: false)
        {
        }
    }

    public class ProductConfigValidator : AbstractValidator<ProductConfig>
    {
        public ProductConfigValidator()
        {
            RuleFor(x => x.BusinessModel).SetValidator(new BusinessModelConfigValidator());
        }
    }
}